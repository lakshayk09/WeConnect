import React, {useState, useEffect} from 'react';
import { useLocation, useNavigate, Link } from 'react-router-dom';
import "../styles/Profile.css"
import axios from 'axios';

//TODO: adding profile pic url and removing it, doesnt display blank pic again

function Profile(props) {
    const blankprofile = "https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png";
    const platformOptions = ["Youtube", "Instagram", "Tiktok", "Twitch"]
    const designationOptions = ["Video Editor", "Art Design", "VFX Artist", "Voice Actor", "Cameraman"]
    const roleOptions = ["Content Creator", "Collaborator"]

    const location = useLocation()      
    const navigate = useNavigate()


    const [name, setName] = useState(location.state.name)
    const [email, setEmail] = useState(location.state.email)    //! this must not be changed, user email has already been registered
    const [profilepic, setProfilePic] = useState(blankprofile)  // acccepts url string
    const [role, setRole] = useState(roleOptions[0])
    const [platform, setPlatform] = useState(platformOptions[0])
    const [designation, setDesignation] = useState(designationOptions[0])
    const [clients, setClients] = useState(0)
    const [experience, setExperience] = useState(0)
    const [connections, setConnections] = useState(0)   //! user can't change this
    const [endorsement, setEndorsement] = useState(0)   //! user can't change this
    const [github, setGithub] = useState("")
    const [linkedin, setLinkedin] = useState("")
    const [fiverr, setFiverr] = useState("")
    const [upwork, setUpwork] = useState("")
    

    const handleSubmit = (e) => {
        e.preventDefault();
        axios.post('http://localhost:3001/profile', {name, email, profilepic, role, platform, designation, clients, experience, connections, endorsement, github, linkedin, fiverr, upwork})
        .then(result => {
            console.log(result)
            navigate('/home', {state: result.data})
        })
        .catch(err => console.log(err))
    }
    
    return(
        <div className='d-flex justify-content-center align-items-center bg-dark Profile'>
            <div className='bg-white p-3 rounded mt-3 mb-3'>
                <img src={profilepic} alt='profilepic' id='profile-pic'></img>
                <form onSubmit={handleSubmit}>
                    <div className='mb-3'>
                        <label htmlFor="name"><strong>Name</strong></label>
                        <input
                            type="text"
                            placeholder='Enter Name'
                            autoComplete='off'
                            name='name'
                            className='form-control rounded-0'
                            value={location.state.name}
                            onChange ={(e) => setName(e.target.value)}
                            disabled
                            />
                    </div>
                    <div className='mb-3'>
                        <label htmlFor="email"><strong>Email</strong></label>
                        <input
                            type="email"
                            autoComplete='off'
                            name='email'
                            className='form-control rounded-0'
                            value={location.state.email}
                            disabled
                            />
                    </div>
                    <div className='mb-3'>
                        <label htmlFor="image"><strong>Profile Pic URL</strong></label>
                        <input
                            type="text"
                            placeholder='Enter url address for profile picture'
                            autoComplete='off'
                            name='image'
                            className='form-control rounded-0'
                            onChange ={(e) => setProfilePic(e.target.value)}
                            />
                    </div>
                    <div className='mb-3'>
                        <label htmlFor="role"><strong>Role</strong></label>
                        <select
                            value={role}
                            required
                            name='role'
                            className='form-control rounded-0'
                            onChange ={(e) => setRole(e.target.value)}>
                                {roleOptions.map(option => (
                                    <option key={option} value={option}>{option}</option>
                                ))}
                        </select>
                    </div>
                    <div className='mb-3'>
                        <label htmlFor="platform"><strong>Platform</strong></label>
                        <select
                            value={platform}
                            required
                            name='platform'
                            className='form-control rounded-0'
                            onChange ={(e) => setPlatform(e.target.value)}>
                                {platformOptions.map(option => (
                                    <option key={option} value={option}>{option}</option>
                                ))}
                        </select>
                    </div>
                    <div className='mb-3'>
                        <label htmlFor="designation"><strong>Designation</strong></label>
                        <select
                            value={designation}
                            required
                            name='designation'
                            className='form-control rounded-0'
                            onChange ={(e) => setDesignation(e.target.value)}>
                                {designationOptions.map(option => (
                                    <option key={option} value={option}>{option}</option>
                                ))}
                        </select>
                    </div>
                    <div className='mb-3'>
                        <label htmlFor="clients"><strong>Clients</strong></label>
                        <input
                            type="number"
                            placeholder="Number of clients you've worked with till date"
                            autoComplete='off'
                            name='clients'
                            className='form-control rounded-0'
                            onChange ={(e) => setClients(e.target.value)}
                            required
                            />
                    </div>
                    <div className='mb-3'>
                        <label htmlFor="experience"><strong>Experience</strong></label>
                        <input
                            type="number"
                            placeholder="Years of experience"
                            autoComplete='off'
                            name='experience'
                            className='form-control rounded-0'
                            onChange ={(e) => setExperience(e.target.value)}
                            required
                            />
                    </div>
                    <div className='mb-3'>
                        <label htmlFor="github"><strong>Github Profile</strong></label>
                        <input
                            type="text"
                            placeholder='Enter your github profile link'
                            autoComplete='off'
                            name='hithub'
                            className='form-control rounded-0'
                            onChange ={(e) => setGithub(e.target.value)}
                            required
                            />
                    </div>
                    <div className='mb-3'>
                        <label htmlFor="linkedin"><strong>Linkedin Profile</strong></label>
                        <input
                            type="text"
                            placeholder='Enter your LinkedIn profile lnk'
                            autoComplete='off'
                            name='linkedin'
                            className='form-control rounded-0'
                            onChange ={(e) => setLinkedin(e.target.value)}
                            />
                    </div>
                    <div className='mb-3'>
                        <label htmlFor="fiverr"><strong>Fiverr Profile</strong></label>
                        <input
                            type="text"
                            placeholder='Enter your Fiverr profile link'
                            autoComplete='off'
                            name='fiverr'
                            className='form-control rounded-0'
                            onChange ={(e) => setFiverr(e.target.value)}
                            />
                    </div>
                    <div className='mb-3'>
                        <label htmlFor="upwork"><strong>Upwork Profile</strong></label>
                        <input
                            type="text"
                            placeholder='Enter your Upwork profile link'
                            autoComplete='off'
                            name='upwork'
                            className='form-control rounded-0'
                            onChange ={(e) => setUpwork(e.target.value)}
                            />
                    </div>
                    <button type="submit" className="btn btn-success w-100 rounded-0">
                        Submit
                    </button>
                </form>
            </div>
        </div>
    )
}

export default Profile;