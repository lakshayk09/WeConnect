import React from 'react'
import { useLocation } from 'react-router-dom';
import Navbar from '../components/Navbar';
import Headline from '../components/Headline';
import Footer from '../components/Footer';
import Selection from '../components/Selection';
import '../styles/Home.css'

function Home(props) {
    const location = useLocation();

    return (
        <div className='Home'>
            { props.isLoggedIn ? 
            <Navbar isLoggedIn={props.isLoggedIn} username={location.state.name} profilepic={location.state.profilepic}/> 
            : 
            <Navbar isLoggedIn={props.isLoggedIn} />
            }

            <Headline />
            <Selection />
            <Footer />
        </div>
    )
}

export default Home;
