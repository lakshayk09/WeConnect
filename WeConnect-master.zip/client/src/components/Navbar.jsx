import React from "react";
import { Navigate } from "react-router-dom";
import NavtoggleLeft from "./NavtoggleLeft";
import NavtoggleRight from "./NavtoggleRight";
import { Link } from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.min.css'

function Navbar(props) {
    return (
        <div className="navbar bg-dark">
            <NavtoggleLeft />
            {props.isLoggedIn ? 
                <div className="navbar">
                    <h5 className="text-light mr-3">{props.username}</h5> 
                    <NavtoggleRight profilepic={props.profilepic}/>
                </div>
                : 
                <Link to="/login" className="btn login-button btn-dark w-100 bg-dark rounded-0 ">Login</Link>
            }
        </div>
    )
}

export default Navbar;