import React, {useState, useEffect} from "react"
import "../styles/Selection.css"
// import "../styles/ProfileCard.css"
import ProfileCard from "./ProfileCard"
import axios from "axios"

function Selection(props) {
    let selectOptions = ["Youtube", "Instagram", "Tiktok", "Twitch"]
    const [selection, setSelection] = useState("")

    const [data, setData] = useState([])


    const handleClick = (opt) => {
        axios.post('http://localhost:3001/data', {opt})
        .then(result => {
            console.log(result.data)
            result.data.map((obj) => {
                console.log(obj.profilepic)
                console.log(obj.name)
            })
            setData(result.data)
        })
        console.log(opt)
        setSelection(opt)
    };

    return (
        <div>
            <div className="Selection bg-dark">
                <nav className="navbar navbar-expand-lg navbar-dark bg-dark selection-bar">
                    <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul className="navbar-nav mr-auto ml-auto" style={{ display: 'flex', justifyContent: 'center', listStyleType: 'none', padding: 0 }}>
                            {selectOptions.map((opt, index) => (
                                <li key={index} className="nav-item" style={{ margin: '0 30px' }}>
                                    <a className={opt === selection ? "nav-link selected" : "nav-link"} onClick={() => handleClick(opt)} style={{ cursor: 'pointer' }}>{opt}</a>
                                </li>
                            ))}
                        </ul>
                    </div>
                </nav>
            </div>
            <div className="card-container bg-dark pb-5">
                {data.map((obj) => {
                    return <ProfileCard image={obj.profilepic} name={obj.name} designation={obj.designation} />
                })}
            </div>
        </div>
    )
}

export default Selection;