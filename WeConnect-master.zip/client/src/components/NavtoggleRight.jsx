import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min.js'; 
import Profile from '../images/blank-profile.png'
import Logo from "../images/logo.png"
import { Link } from "react-router-dom";
import '../styles/Navbar.css'

function NavtoggleRight(props) {

    return (
        <div>
            {props.profilepic ?
            <img src={props.profilepic} alt="Profile" className="img-fluid profile-photo" data-bs-toggle="offcanvas" data-bs-target="#offcanvasRight" aria-controls="offcanvasRight" style={{ cursor: 'pointer'}} />
            :
            <img src={Profile} alt="Profile" className="img-fluid profile-photo" data-bs-toggle="offcanvas" data-bs-target="#offcanvasRight" aria-controls="offcanvasRight" style={{ cursor: 'pointer'}} />
            }
            <div className="offcanvas offcanvas-end bg-dark" tabIndex="-1" id="offcanvasRight" aria-labelledby="offcanvasRightLabel">
                <div className="offcanvas-header">
                    {props.profilepic ? 
                        <img src={props.profilepic} className="img-fluid Profile-big" alt="profilepic"></img>
                        :
                        <img src={Profile} className="img-fluid Profile-big" alt="profilepic"></img>
                    }
                    <button type="button" className="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                </div>
                <div className="offcanvas-body">
                    <ul>
                        <li>
                            <button type='button' className="navbar-toggle-buttons bg-dark" data-bs-dismiss="offcanvas" aria-label='Close'>
                                <Link to="/" className="btn btn-dark w-20 rounded-1">Your Profile</Link>
                            </button>
                        </li>
                        <li>
                            <button type='button' className="navbar-toggle-buttons bg-dark" data-bs-dismiss="offcanvas" aria-label='Close'>
                                <Link to="/" className="btn btn-dark w-20 rounded-1">Sign Out</Link>
                            </button>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    )
}

export default NavtoggleRight;
