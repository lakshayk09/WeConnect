import HeadlineImage from '../images/headline-image.png'
import { useNavigate } from 'react-router-dom'
import '../styles/Headline.css'

function Headline() {
    const navigate = useNavigate()
    const handleClick = () => {
        navigate('/login')
    }
    return (
        <div className="container-fluid vh-50 bg-dark">
            <div className="row">
                <div className="headline col-6  text-start text-light ml-5 mt-5">
                    <h1 className="heading ">WeConnect</h1>
                    <h3 className="subheading">Your Hub for Content Creators</h3>
                    <p className='promo'> Dive into a vibrant community of content creators on WeConnect, where you can discover like-minded individuals, collaborate on projects, and showcase your work. Connect, create, and inspire together in this dynamic hub for content creation.</p>
                    <a className="btn btn-dark" onClick={handleClick}>Get Started</a>
                </div>
                <div className="col-4">
                    <img className="img-fluid headline-image" src={HeadlineImage} ></img>
                </div>
            </div>
        </div>
    )
}

export default Headline;