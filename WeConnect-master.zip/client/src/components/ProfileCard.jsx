import React from "react";

function ProfileCard(props) {
    return (
        <div className="card ">
            <img src={props.image} alt={props.name}></img>
            <div className="card-content">
                <h3>{props.name}</h3>
                <h5>{props.designation}</h5>
                <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Debitis molestias commodi odio facere repudiandae, fugiat facilis deserunt cupiditate, aliquam consequatur autem excepturi similique sunt quas esse dolor nisi quis placeat?</p>
                <a className="btn btn-dark">Read More</a>
            </div>
        </div>
    )
}

export default ProfileCard