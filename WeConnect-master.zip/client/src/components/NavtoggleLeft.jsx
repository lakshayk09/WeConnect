import 'bootstrap/dist/css/bootstrap.min.css'
import 'bootstrap/dist/js/bootstrap.bundle.min.js'; 
import Logo from "../images/logo.png"
import LogoGlobe from "../images/logo-globe.png"
import { Link } from "react-router-dom";
import '../styles/Navbar.css'

function NavtoggleLeft() {
    return (
        <div className='navtoggleleft'>
            {/* Replace button with an image */}
            <img src={LogoGlobe} alt="Logo" className="img-fluid logo-globe" data-bs-toggle="offcanvas" data-bs-target="#offcanvasLeft" aria-controls="offcanvasLeft" style={{ cursor: 'pointer'}} />

            <div className="offcanvas offcanvas-start bg-dark"  tabIndex="-1" id="offcanvasLeft" aria-labelledby="offcanvasLeftLabel">
                <div className="offcanvas-header">
                    <img src={Logo} className="img-fluid" alt="logo"></img>
                    <button type="button" className="btn-close btn-dark text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                </div>
                <div className="offcanvas-body">
                    <ul>
                        <li><Link to="/" className="btn btn-dark w-20 rounded-1 mb-2 ">Home</Link></li>
                        <li><Link to="/" className="btn btn-dark w-20  rounded-1 mb-2">Settings</Link></li>
                        <li><Link to="/" className="btn btn-dark w-20 rounded-1 mb-2">Contact Us</Link></li>
                    </ul>
                </div>
            </div>
        </div>
    )
}

export default NavtoggleLeft;