import React from "react";
import '../styles/Footer.css'

function Footer() {
    return (
        <section id="Footer" className="container-fluid bg-dark">
            <div class="row Links">
                <div class="col-md-7">
                    <a >About</a>
                    <a class="Contact-Link2">Contact Us</a>
                    <a >Download App</a>
                </div>
                <div class="col-md-5 text-md-right pt-4 pt-md-0">
                    <a href="twitter.com"><i class="fa-brands fa-x-twitter"></i></a>
                    <a href="instagram.com"><i class="fa-brands fa-instagram"></i></a>
                    <a href="facebook.com"><i class="fa-brands fa-facebook"></i></a>
                </div>
            </div>

            <div class="row Copyright">
                <div class="col text-center">
                    <p>Copyright ©2023 WeConnect. All rights reserved</p>
                </div>
            </div>
        </section>
    )
}
export default Footer