import { useState } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css'
import Register from './pages/Register'
import Home from './pages/Home'
import Login from './pages/Login'
import Profile from './pages/Profile'
import {BrowserRouter, Routes, Route} from 'react-router-dom'


function App() {

  return (
    <BrowserRouter>
      <Routes>
        <Route exact path='/' element={<Home isLoggedIn={false}/>}></Route>
        <Route path='/home' element={<Home isLoggedIn={true}/>}></Route>
        <Route path='/register' element={<Register />}></Route>
        <Route path='/login' element={<Login />}></Route>
        <Route path='/profile' element={<Profile isLoggedIn={true} />}></Route>
      </Routes>
    </BrowserRouter>
  )
}

export default App
