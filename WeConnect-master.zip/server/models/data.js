const mongoose = require('mongoose')

//this will store user's data about their projects and stuff
const DataSchema = new mongoose.Schema({
    name: String,
    email: String,
    profilepic: String,
    role: String,
    platform: String,
    designation: String,
    clients: Number,
    experience: Number,
    connections: Number,
    endorsement: Number,
    github: String,
    linkedin: String,
    fiverr: String,
    upwork: String
})

const DataModel = mongoose.model('data', DataSchema)

module.exports = DataModel