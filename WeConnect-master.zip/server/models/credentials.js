const mongoose = require('mongoose')

// Schema = create a structure of the table
//this will store user credentials
const UsersSchema = new mongoose.Schema({
    name: String,
    email: String,
    password: String
})


// create the table from the schema
const UsersModel = mongoose.model('info', UsersSchema)


// send the model object to server (index.js)
module.exports = UsersModel
