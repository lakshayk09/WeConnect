const express = require('express');
const mongoose = require('mongoose')
const cors = require('cors')
const UsersModel = require('./models/credentials');
const DataModel = require('./models/data');
const PORT = 3001

const app = express()
app.use(express.json()) //receive the data from front end to back end in json format
app.use(cors())

// mongoose.connect("mongodb://localhost:27017/users")  //local database connection string
mongoose.connect("mongodb://127.0.0.1:27017/users")  //if the above doesn't work use this

//handle the post request coming from frontend (i.e adding the user into the model/table)
app.post('/register', (req, res) => {       // register is the page/route through which data is coming, request is the data coming, result is something we'll return back to frontend
    UsersModel.create(req.body)             // insert data in stored in req.body, into UsersModel
    .then(user => res.json(user))         // return back json of the data inserted 
    .catch(err => res.json(err))            //send error in result
})

app.post('/profile', (req,res) => {
    DataModel.create(req.body)
    .then(user => res.json(user))
    .catch(err => res.json(err))
})

app.post('/login', (req,res) => {
    const {email, password} = req.body
    UsersModel.findOne({email: email})      //checks for a record in the table
    .then(user => {
        if(user) {
            if(user.password === password){
                obj = {...user, loginResponse: "Success"}
                res.json(obj)
            } else {
                obj = {...user, loginResponse: "Incorrect Password"}
                res.json(obj)
            }
        } else {
            obj = {...user, loginResponse: "No record found"}
            res.json(obj)
        }
    })
    .catch(err => console.log(err))
})

app.post('/data', (req,res) => {
    const {opt} = req.body
    DataModel.find({platform: opt})
    .then(users => {
        if(users) {
            res.json(users)
        } else {
            res.json("Error datamodel.find")
        }
    })
    .catch(err => console.log(err))
})

app.listen(PORT, () => {      //start server on port 3001
    console.log(`Server is running on ${PORT}`)
})